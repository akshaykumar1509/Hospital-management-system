from django.apps import AppConfig


class HospitalappConfig(AppConfig):
    name = 'hospitalapp'
